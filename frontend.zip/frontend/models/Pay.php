<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "pay".
 *
 * @property int $id
 * @property string $name 支付方式名称
 * @property string $explain 支付说明
 */
class Pay extends \yii\db\ActiveRecord
{

}
