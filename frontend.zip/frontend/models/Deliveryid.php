<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "deliveryid".
 *
 * @property int $id
 * @property string $name
 * @property string $freight
 */
class Deliveryid extends \yii\db\ActiveRecord
{



}
